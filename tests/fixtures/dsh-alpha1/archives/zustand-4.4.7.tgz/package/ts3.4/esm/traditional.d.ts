import { Mutate, StateCreator, StoreApi, StoreMutatorIdentifier } from './vanilla';
type ExtractState<S> = S extends {
    getState: () => infer T;
} ? T : never;
type ReadonlyStoreApi<T> = Pick<StoreApi<T>, 'getState' | 'subscribe'>;
type WithReact<S extends ReadonlyStoreApi<unknown>> = S & {
    getServerState?: () => ExtractState<S>;
};
export declare function useStoreWithEqualityFn<S extends WithReact<StoreApi<unknown>>>(api: S): ExtractState<S>;
export declare function useStoreWithEqualityFn<S extends WithReact<StoreApi<unknown>>, U>(api: S, selector: (state: ExtractState<S>) => U, equalityFn?: (a: U, b: U) => boolean): U;
export type UseBoundStoreWithEqualityFn<S extends WithReact<ReadonlyStoreApi<unknown>>> = {
    (): ExtractState<S>;
    <U>(selector: (state: ExtractState<S>) => U, equalityFn?: (a: U, b: U) => boolean): U;
} & S;
type CreateWithEqualityFn = {
    <T, Mos extends [
        StoreMutatorIdentifier,
        unknown
    ][] = [
    ]>(initializer: StateCreator<T, [
    ], Mos>, defaultEqualityFn?: <U>(a: U, b: U) => boolean): UseBoundStoreWithEqualityFn<Mutate<StoreApi<T>, Mos>>;
    <T>(): <Mos extends [
        StoreMutatorIdentifier,
        unknown
    ][] = [
    ]>(initializer: StateCreator<T, [
    ], Mos>, defaultEqualityFn?: <U>(a: U, b: U) => boolean) => UseBoundStoreWithEqualityFn<Mutate<StoreApi<T>, Mos>>;
};
export declare const createWithEqualityFn: CreateWithEqualityFn;
export {};
