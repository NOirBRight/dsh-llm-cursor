/**
 * Map Cursor interactionUpdate frames onto DSH StreamChunks.
 * args_text_delta is a cumulative snapshot; only the unmatched suffix is emitted.
 */
import type { StreamChunk, TokenUsage } from '@deepseek-ai/dsh-llm';
import type { InteractionUpdate, ToolCall } from './wire/vendor/agent_pb.ts';
export declare function isMcpToolCall(toolCall: ToolCall | undefined): boolean;
export declare function isIgnoredToolCall(toolCall: ToolCall | undefined): boolean;
export declare function mcpToolName(toolCall: ToolCall | undefined): string | undefined;
export declare function snapshotDelta(previous: string, snapshot: string): string;
export interface OpenMcpBlock {
    envelopeCallId: string;
    toolCallId: string;
    index: number;
    name: string;
    arguments: string;
    completed: boolean;
}
export declare class InteractionMapper {
    private readonly ignoredMcpCallIds;
    private nextIndex;
    private textIndex;
    private text;
    private reasoningIndex;
    private reasoning;
    private readonly mcp;
    private outputTokens;
    private inputTokens;
    sawTokenDelta: boolean;
    turnEnded: boolean;
    chunks: StreamChunk[];
    constructor(ignoredMcpCallIds?: ReadonlySet<string>);
    take(): StreamChunk[];
    /** Return known token usage, or `undefined` when the protocol supplied neither counter. */
    usage(): TokenUsage | undefined;
    /** Return whether the provider reported any generated tokens. */
    hasOutputTokens(): boolean;
    openMcpBlocks(): OpenMcpBlock[];
    completedMcpBlocks(): OpenMcpBlock[];
    hasIncompleteMcp(): boolean;
    applyCheckpointUsedTokens(used: number): void;
    handle(update: InteractionUpdate): void;
    completeMcpFromExec(toolCallIdValue: string, name: string, args: string): void;
    flushOpenText(): void;
    private ensureText;
    private closeText;
    private ensureReasoning;
    private closeReasoning;
    private openMcp;
    private applyArgsSnapshot;
    private completeMcp;
    private finishMcp;
}
//# sourceMappingURL=interaction.d.ts.map